package cmd

import (
	"fmt"
	"os"
	"os/signal"
	"syscall"
	"time"

	corecmd "github.com/Axway/agent-sdk/pkg/cmd"
	"github.com/Axway/agent-sdk/pkg/cmd/properties"
	corecfg "github.com/Axway/agent-sdk/pkg/config"

	// CHANGE_HERE - Change the import path(s) below to reference packages correctly
	"github.com/someorg/samples/apic_discovery_agent/pkg/config"
	"github.com/someorg/samples/apic_discovery_agent/pkg/gateway"
)

// RootCmd - Agent root command
var RootCmd corecmd.AgentRootCmd
var gatewayClient *gateway.GatewayClient
var gatewayConfig *config.GatewayConfig

func init() {
	// Create new root command with callbacks to initialize the agent config and command execution.
	// The first parameter identifies the name of the yaml file that agent will look for to load the config
	RootCmd = corecmd.NewRootCmd(
		"apic_discovery_agent",   // Name of the yaml file
		"Sample Discovery Agent", // Agent description
		initConfig,               // Callback for initializing the agent config
		run,                      // Callback for executing the agent
		corecfg.DiscoveryAgent,   // Agent Type (Discovery or Traceability)
	)

	// Get the root command properties and bind the config property in YAML definition
	rootProps := RootCmd.GetProperties()
	rootProps.AddStringProperty("gateway.specPath", "./apis", "Sample Swagger specification path for discovery")
	rootProps.AddDurationProperty("gateway.pollInterval", 5*time.Minute, "Poll Interval", properties.WithLowerLimit(30*time.Second))
	rootProps.AddStringProperty("gateway.configKey1", "", "Config Key 1")
	rootProps.AddStringProperty("gateway.configKey2", "", "Config Key 1")
	rootProps.AddStringProperty("gateway.configKey3", "", "Config Key 3")

}

// Callback that agent will call to process the execution
func run() error {
	sigs := make(chan os.Signal, 1)
	signal.Notify(sigs, syscall.SIGINT, syscall.SIGTERM, syscall.SIGHUP)
	timer := time.NewTimer(0)
	for {
		select {
		case <-sigs:
			fmt.Println("terminating agent")
			return nil
		case <-timer.C:
			err := gatewayClient.DiscoverAPIs()
			if err != nil {
				return err
			}
			timer.Reset(time.Second * gatewayConfig.PollInterval)
		}
	}
}

// Callback that agent will call to initialize the config. CentralConfig is parsed by Agent SDK
// and passed to the callback allowing the agent code to access the central config
func initConfig(centralConfig corecfg.CentralConfig) (interface{}, error) {
	rootProps := RootCmd.GetProperties()
	// Parse the config from bound properties and setup gateway config
	gatewayConfig = &config.GatewayConfig{
		SpecPath:     rootProps.StringPropertyValue("gateway.specPath"),
		PollInterval: rootProps.DurationPropertyValue("gateway.pollInterval"),
		ConfigKey1:   rootProps.StringPropertyValue("gateway.configKey1"),
		ConfigKey2:   rootProps.StringPropertyValue("gateway.configKey2"),
		ConfigKey3:   rootProps.StringPropertyValue("gateway.configKey3"),
	}

	agentConfig := config.AgentConfig{
		CentralCfg: centralConfig,
		GatewayCfg: gatewayConfig,
	}

	var err error
	gatewayClient, err = gateway.NewClient(gatewayConfig)
	if err != nil {
		return nil, err
	}

	return agentConfig, nil
}
