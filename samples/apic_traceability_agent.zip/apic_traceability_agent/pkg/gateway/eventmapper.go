package gateway

import (
	"encoding/json"
	"net/http"
	"strconv"
	"time"

	"github.com/Axway/agent-sdk/pkg/agent"
	"github.com/Axway/agent-sdk/pkg/transaction"
	"github.com/Axway/agent-sdk/pkg/util/log"
)

// EventMapper -
type EventMapper struct {
}

func (m *EventMapper) processMapping(gatewayTrafficLogEntry GwTrafficLogEntry) []transaction.LogEvent {
	centralCfg := agent.GetCentralConfig()

	transInboundLogEventLeg := transaction.LogEvent{
		Version:           "1.0",
		Stamp:             time.Now().Unix(),
		TransactionID:     gatewayTrafficLogEntry.TraceID,
		TenantID:          centralCfg.GetTenantID(),
		TrcbltPartitionID: centralCfg.GetTenantID(),
		APICDeployment:    centralCfg.GetAPICDeployment(),
		EnvironmentID:     centralCfg.GetEnvironmentID(),
		Environment:       centralCfg.GetEnvironmentName(),
		Type:              transaction.TypeTransactionEvent,
		TransactionEvent:  m.createTransactionEvent(gatewayTrafficLogEntry.InboundTransaction, "", "INBOUND", ""),
	}

	transOutboundLogEventLeg := transaction.LogEvent{
		Version:           "1.0",
		Stamp:             time.Now().Unix(),
		TransactionID:     gatewayTrafficLogEntry.TraceID,
		TenantID:          centralCfg.GetTenantID(),
		TrcbltPartitionID: centralCfg.GetTenantID(),
		APICDeployment:    centralCfg.GetAPICDeployment(),
		EnvironmentID:     centralCfg.GetEnvironmentID(),
		Environment:       centralCfg.GetEnvironmentName(),
		Type:              transaction.TypeTransactionEvent,
		TransactionEvent:  m.createTransactionEvent(gatewayTrafficLogEntry.OutboundTransaction, gatewayTrafficLogEntry.InboundTransaction.ID, "OUTBOUND", ""),
	}

	transSummaryLogEvent := transaction.LogEvent{
		Version:            "1.0",
		Stamp:              time.Now().Unix(),
		TransactionID:      gatewayTrafficLogEntry.TraceID,
		TenantID:           centralCfg.GetTenantID(),
		TrcbltPartitionID:  centralCfg.GetTenantID(),
		APICDeployment:     centralCfg.GetAPICDeployment(),
		EnvironmentID:      centralCfg.GetEnvironmentID(),
		Environment:        centralCfg.GetEnvironmentName(),
		Type:               transaction.TypeTransactionSummary,
		TransactionSummary: m.createSummaryEvent(gatewayTrafficLogEntry, centralCfg.GetTeamID()),
	}

	return []transaction.LogEvent{
		transSummaryLogEvent,
		transInboundLogEventLeg,
		transOutboundLogEventLeg,
	}
}

func (m *EventMapper) getTransactionStatus(code int) string {
	if code >= 400 {
		return "FAIL"
	}
	return "PASS"
}

func (m *EventMapper) buildHeaders(headers map[string]string) string {
	jsonHeader, err := json.Marshal(headers)
	if err != nil {
		log.Error(err.Error())
	}
	return string(jsonHeader)
}

func (m *EventMapper) createTransactionEvent(gatewayTransaction GwTransaction, parentID, direction, userAgent string) *transaction.Event {

	return &transaction.Event{
		ID:          gatewayTransaction.ID,
		ParentID:    parentID,
		Source:      gatewayTransaction.SourceHost + ":" + strconv.Itoa(gatewayTransaction.SourcePort),
		Destination: gatewayTransaction.DesHost + ":" + strconv.Itoa(gatewayTransaction.DestPort),
		Duration:    0,
		Direction:   direction,
		Status:      m.getTransactionStatus(gatewayTransaction.StatusCode),
		Protocol: &transaction.Protocol{
			Type:            "http",
			URI:             gatewayTransaction.URI,
			Args:            "",
			Method:          gatewayTransaction.Method,
			Status:          gatewayTransaction.StatusCode,
			StatusText:      http.StatusText(gatewayTransaction.StatusCode),
			UserAgent:       userAgent,
			Host:            gatewayTransaction.SourceHost,
			Version:         "",
			RequestHeaders:  m.buildHeaders(gatewayTransaction.RequestHeaders),
			ResponseHeaders: m.buildHeaders(gatewayTransaction.ResponseHeaders),
			BytesSent:       gatewayTransaction.RequestBytes,
			BytesReceived:   gatewayTransaction.ResponseBytes,
			RemoteName:      "",
			RemoteAddr:      gatewayTransaction.DesHost,
			RemotePort:      gatewayTransaction.DestPort,
			LocalAddr:       gatewayTransaction.SourceHost,
			LocalPort:       gatewayTransaction.SourcePort,
		},
	}
}

func (m *EventMapper) createSummaryEvent(gatewayTrafficLogEntry GwTrafficLogEntry, teamID string) *transaction.Summary {
	transSummaryStatus := "Unknown"
	statusCode := gatewayTrafficLogEntry.InboundTransaction.StatusCode
	if statusCode >= http.StatusOK && statusCode < http.StatusBadRequest {
		transSummaryStatus = "Success"
	} else if statusCode >= http.StatusBadRequest && statusCode < http.StatusInternalServerError {
		transSummaryStatus = "Failure"
	} else if statusCode >= http.StatusInternalServerError && statusCode < http.StatusNetworkAuthenticationRequired {
		transSummaryStatus = "Exception"
	}

	return &transaction.Summary{
		Status:       transSummaryStatus,
		StatusDetail: strconv.Itoa(gatewayTrafficLogEntry.InboundTransaction.StatusCode),
		Duration:     0,
		Team: &transaction.Team{
			ID: teamID,
		},
		EntryPoint: &transaction.EntryPoint{
			Type:   "http",
			Method: gatewayTrafficLogEntry.InboundTransaction.Method,
			Path:   gatewayTrafficLogEntry.InboundTransaction.URI,
			Host:   gatewayTrafficLogEntry.InboundTransaction.SourceHost,
		},
		Proxy: &transaction.Proxy{
			Name:     "",
			ID:       "unknown",
			Revision: 0,
		},
		// If the API is published to Central as unified catalog item/API service, se the Proxy details with the API definition
		// The Proxy.Name represents the name of the API
		// The Proxy.ID should be of format "remoteApiId_<ID Of the API on remote gateway>". Use transaction.FormatProxyID(<ID Of the API on remote gateway>) to get the formatted value.
		// Proxy: &transaction.Proxy{
		// 	Name:     "",
		// 	ID:       "unknown",
		// 	Revision: 0,
		// },
	}
}
